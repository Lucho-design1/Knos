"""Sealed hidden tests: a bundle the pull request's author cannot read, fixed by its hash, of which only counts leave.

    pack(folder) -> bytes          a deterministic tar.gz of the folder (sorted names, no owner, no time, no links)
    seal(bundle) -> str            its sha256: the value `hidden_tests.sha256` of .knos/gate.yml holds
    encode / decode                the bundle as one base64 line, the value of the repository secret
    unpack(bundle, dest, sha256)   refuses a bundle whose hash is not the seal, an absolute name, `..`, a link or a
                                   device; returns the paths it wrote (relative to dest)
    run(command, cwd, ...)         the suite on the pull request's tree, in a sandbox: an environment with no token
                                   and no secret, no network when the runner allows it (`sudo unshare --net`), its
                                   output kept in a file that is never printed; pytest's JUnit report gives the counts
    counts(junit_xml)              {"total","passed","failed","errors","skipped"} and nothing else: no test name, no
                                   message, no line of output
    leaks(text, files)             the lines of the hidden files (12 characters or more) a text would give away;
                                   everything Gate posts goes through it first

What the sandbox does not stop: the pull request's code runs in the same process as the hidden tests, so it can read
them while they run and can try to fake their result. It has no network and no token to send them anywhere, its
output is never shown, and the cheat library refuses the edits that fake a result (runner_tampering,
runner_forgery). docs/reference/PR_GATE.md says this in its limits."""
from __future__ import annotations

import base64
import gzip
import hashlib
import io
import os
import shlex
import shutil
import subprocess
import tarfile
import xml.etree.ElementTree as ET
from pathlib import Path

MAX_BUNDLE = 48 * 1024        # a GitHub secret holds at most 48 KB; larger suites go in a private repository
_KEEP_ENV = ("PATH", "LANG", "LC_ALL", "PYTHONHASHSEED", "VIRTUAL_ENV", "PYTHONPATH")


class Refused(ValueError):
    """The bundle is not the sealed one, or cannot be unpacked safely."""


def pack(folder: Path | str) -> bytes:
    root = Path(folder)
    if not root.is_dir():
        raise Refused(f"{folder} is not a folder")
    raw = io.BytesIO()
    with tarfile.open(fileobj=raw, mode="w", format=tarfile.PAX_FORMAT) as tar:
        for p in sorted(root.rglob("*"), key=lambda q: q.relative_to(root).as_posix()):
            rel = p.relative_to(root).as_posix()
            if any(part in ("__pycache__", ".pytest_cache") for part in rel.split("/")) or p.suffix == ".pyc":
                continue
            if p.is_symlink():
                raise Refused(f"{rel} is a link: a sealed bundle holds files only")
            if not p.is_file():
                continue
            data = p.read_bytes()
            info = tarfile.TarInfo(rel)
            info.size, info.mode, info.mtime, info.uid, info.gid, info.uname, info.gname = len(data), 0o644, 0, 0, 0, "", ""
            tar.addfile(info, io.BytesIO(data))
    out = io.BytesIO()
    with gzip.GzipFile(fileobj=out, mode="wb", mtime=0, compresslevel=9) as gz:
        gz.write(raw.getvalue())
    return out.getvalue()


def seal(bundle: bytes) -> str:
    return hashlib.sha256(bundle).hexdigest()


def encode(bundle: bytes) -> str:
    return base64.b64encode(bundle).decode()


def decode(text: str) -> bytes:
    try:
        return base64.b64decode("".join(text.split()), validate=True)
    except ValueError:
        raise Refused("the hidden-test secret is not base64 (`knos gate seal DIR` prints the value to store)") from None


def unpack(bundle: bytes, dest: Path | str, sha256: str) -> list[str]:
    got = seal(bundle)
    if got != sha256:
        raise Refused(f"the hidden tests are not the sealed ones (sha256 {got[:12]}..., sealed {sha256[:12]}...)")
    dest = Path(dest)
    dest.mkdir(parents=True, exist_ok=True)
    written = []
    with tarfile.open(fileobj=io.BytesIO(bundle), mode="r:gz") as tar:
        for m in tar.getmembers():
            name = m.name
            if name.startswith("/") or ".." in name.split("/") or "\\" in name:
                raise Refused(f"the bundle names {name!r}, outside its folder")
            if not (m.isfile() or m.isdir()):
                raise Refused(f"the bundle holds {name!r}, which is not a file")
            if m.isdir():
                continue
            target = dest / name
            target.parent.mkdir(parents=True, exist_ok=True)
            f = tar.extractfile(m)
            target.write_bytes(f.read() if f else b"")
            written.append(name)
    return written


def hidden_lines(files: list[Path], min_len: int = 12) -> set[str]:
    out = set()
    for f in files:
        try:
            text = Path(f).read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        out.update(s for s in (ln.strip() for ln in text.splitlines()) if len(s) >= min_len)
    return out


def leaks(text: str, lines: set[str]) -> list[str]:
    """The hidden lines `text` contains. Gate posts nothing that has one."""
    return sorted(ln for ln in lines if ln in text)


def counts(junit: Path | str | None) -> dict:
    """Counts from a JUnit XML report (pytest's --junitxml). A missing or unreadable report counts as one error."""
    zero = {"total": 0, "passed": 0, "failed": 0, "errors": 0, "skipped": 0}
    if not junit or not Path(junit).is_file():
        return {**zero, "errors": 1, "report": "missing"}
    raw = Path(junit).read_bytes()
    if len(raw) > 20_000_000 or b"<!DOCTYPE" in raw or b"<!ENTITY" in raw:
        return {**zero, "errors": 1, "report": "refused"}
    try:
        root = ET.fromstring(raw)
    except ET.ParseError:
        return {**zero, "errors": 1, "report": "unreadable"}
    c = dict(zero)
    for case in root.iter("testcase"):
        c["total"] += 1
        tags = {child.tag for child in case}
        if "failure" in tags:
            c["failed"] += 1
        elif "error" in tags:
            c["errors"] += 1
        elif "skipped" in tags:
            c["skipped"] += 1
        else:
            c["passed"] += 1
    c["report"] = "ok"
    return c


def sandbox_prefix(mode: str = "auto", env: dict | None = None) -> tuple[list[str], str]:
    """(argv prefix, what it is). `nonet`: a new network namespace (no network at all), run as KNOS_GATE_SANDBOX_USER
    (actions/gate makes that user: it cannot write the runner's files, so it cannot reach $GITHUB_ENV or the Knos
    install the verdict is computed with) or else the runner's own user, with exactly `env` and nothing else.
    `none`: no isolation beyond the clean environment. `auto`: nonet when it can be had without a prompt."""
    if mode == "none":
        return [], "none"
    user = os.environ.get("KNOS_GATE_SANDBOX_USER") or os.environ.get("USER") or os.environ.get("LOGNAME") or ""
    if shutil.which("unshare") and shutil.which("sudo") and user:
        try:
            probe = subprocess.run(["sudo", "-n", "unshare", "--net", "true"], capture_output=True, timeout=20)
        except (OSError, subprocess.TimeoutExpired):
            probe = None
        if probe is not None and probe.returncode == 0:
            assigns = [f"{k}={v}" for k, v in sorted((env or {}).items())]
            kind = "nonet,user" if os.environ.get("KNOS_GATE_SANDBOX_USER") else "nonet"
            return ["sudo", "-n", "unshare", "--net", "--", "sudo", "-n", "-u", user, "--", "env", "-i", *assigns], kind
    if mode == "nonet":
        raise Refused("a sandbox with no network was asked for and this runner cannot make one (sudo unshare --net)")
    return [], "none"


def run(command: str, cwd: Path | str, junit: Path | str, log: Path | str, *, timeout: int = 600, sandbox: str = "auto",
        extra_env: dict | None = None) -> dict:
    """Run `command` in `cwd` with a clean environment; pytest commands get --junitxml added. The output goes to
    `log` (never printed). Returns counts(...) plus exit code, sandbox kind and seconds."""
    import time
    argv = shlex.split(command)
    if not argv:
        raise Refused("an empty test command")
    is_pytest = "pytest" in argv[0] or (len(argv) > 2 and argv[1] == "-m" and argv[2] == "pytest")
    if is_pytest:
        argv += [f"--junitxml={junit}", "-p", "no:cacheprovider"]
    home = Path(junit).parent / "home"
    home.mkdir(parents=True, exist_ok=True)
    for d in (home, Path(junit).parent):
        os.chmod(d, 0o777)          # the sandbox user writes its report and its home here, and nothing else of ours
    if Path(junit).exists():
        Path(junit).unlink()
    env = {k: os.environ[k] for k in _KEEP_ENV if k in os.environ}
    env.update({"HOME": str(home), "KNOS_GATE_JUNIT": str(junit), "CI": "true", "PYTHONDONTWRITEBYTECODE": "1", **(extra_env or {})})
    prefix, kind = sandbox_prefix(sandbox, env)
    t0 = time.monotonic()
    with open(log, "wb") as out:
        try:
            done = subprocess.run(prefix + argv, cwd=cwd, env=env, stdout=out, stderr=subprocess.STDOUT, timeout=timeout)
            code = done.returncode
        except subprocess.TimeoutExpired:
            code = -9
        except FileNotFoundError:
            code = 127
    got = counts(junit) if is_pytest else _from_exit(code)
    if is_pytest and got.get("report") != "ok" and code == 0:
        got = _from_exit(code)
    got.update({"exit": code, "sandbox": kind, "seconds": round(time.monotonic() - t0, 2), "timed_out": code == -9})
    return got


def _from_exit(code: int) -> dict:
    """A command that is not pytest: one result, its exit code."""
    ok = code == 0
    return {"total": 1, "passed": int(ok), "failed": int(not ok), "errors": 0, "skipped": 0, "report": "exit-code"}


def passed(c: dict) -> bool:
    return bool(c) and c.get("total", 0) > 0 and c.get("failed", 1) == 0 and c.get("errors", 1) == 0 \
        and c.get("passed", 0) > 0 and not c.get("timed_out")
